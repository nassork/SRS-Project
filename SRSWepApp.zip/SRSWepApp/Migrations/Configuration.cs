namespace SRSWepApp.Migrations
{
    using Microsoft.AspNet.Identity.EntityFramework;
    using Models;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<SRSWepApp.Models.ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(SRSWepApp.Models.ApplicationDbContext context)
        {
            //  This method will be called after migrating to the latest version.

            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            //    context.People.AddOrUpdate(
            //      p => p.FullName,
            //      new Person { FullName = "Andrew Peters" },
            //      new Person { FullName = "Brice Lambson" },
            //      new Person { FullName = "Rowan Miller" }
            //    );
            //

            IdentityRole role = new IdentityRole("Teacher");
            context.Roles.Add(role);
            context.SaveChanges();

            List<Teacher> teacherList = Teacher.PopulateTeacher();
            context.Teachers.AddRange(teacherList);

            context.SaveChanges();

            IdentityUserRole userRole;

            foreach (Teacher eachTeacher in teacherList)
            {
                userRole = new IdentityUserRole();
                userRole.RoleId = role.Id;
                userRole.UserId = eachTeacher.Id;
                eachTeacher.Roles.Add(userRole);
                role.Users.Add(userRole);
            }
            context.SaveChanges();


            role = new IdentityRole("Student");
            context.Roles.Add(role);
            context.SaveChanges();

            List<Student> studentList = Student.PopulateStudent();
            context.Students.AddRange(studentList);

            foreach (Student eachStudent in studentList)
            {
                userRole = new IdentityUserRole();
                userRole.RoleId = role.Id;
                userRole.UserId = eachStudent.Id;
                eachStudent.Roles.Add(userRole);
                role.Users.Add(userRole);
            }

            context.SaveChanges();

            context.SaveChanges();

            List<Course> courseList = Course.PopulateCourse();
            context.Courses.AddRange(courseList);

            context.SaveChanges();

            List<CourseOffering> courseOfferingList = CourseOffering.PopulateCourseOffering();
            context.CourseOfferings.AddRange(courseOfferingList);

            context.SaveChanges();

            List<CourseSignUp> courseSignUpList = CourseSignUp.PopulateCourseSignUp();
            context.CourseSignUps.AddRange(courseSignUpList);

            context.SaveChanges();
        }
    }
}
