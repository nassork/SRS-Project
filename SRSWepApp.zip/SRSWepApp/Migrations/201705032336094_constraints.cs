namespace SRSWepApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class constraints : DbMigration
    {
        public override void Up()
        {
            DropIndex("dbo.CourseSignUps", new[] { "CourseOfferingId" });
            AlterColumn("dbo.AspNetUsers", "GPA", c => c.Double());
            CreateIndex("dbo.CourseSignUps", "CourseOfferingId", unique: true, name: "CourseRegistrationIndex");
        }
        
        public override void Down()
        {
            DropIndex("dbo.CourseSignUps", "CourseRegistrationIndex");
            AlterColumn("dbo.AspNetUsers", "GPA", c => c.Int());
            CreateIndex("dbo.CourseSignUps", "CourseOfferingId");
        }
    }
}
