namespace SRSWepApp.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class startandend : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.CourseOfferings", "StartTime", c => c.Time(nullable: false, precision: 7));
            AddColumn("dbo.CourseOfferings", "EndTime", c => c.Time(nullable: false, precision: 7));
        }
        
        public override void Down()
        {
            DropColumn("dbo.CourseOfferings", "EndTime");
            DropColumn("dbo.CourseOfferings", "StartTime");
        }
    }
}
